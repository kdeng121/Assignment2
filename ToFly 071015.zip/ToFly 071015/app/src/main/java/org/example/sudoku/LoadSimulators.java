package org.example.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;



public class LoadSimulators extends Activity implements OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_simulators);

        View instructionsButton = findViewById(R.id.instructions_button);
        instructionsButton.setOnClickListener(this);

        View martinButton = findViewById(R.id.martin_button);
        martinButton.setOnClickListener(this);
        View edgeButton = findViewById(R.id.edge_button);
        edgeButton.setOnClickListener(this);
        View corsairButton = findViewById(R.id.corsair_button);
        corsairButton.setOnClickListener(this);
        View theaterButton = findViewById(R.id.theater_button);
        theaterButton.setOnClickListener(this);
        View maxflightButton = findViewById(R.id.maxflight_button);
        maxflightButton.setOnClickListener(this);
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.instructions_button:
                Intent i = new Intent(this, SimulatorInstructions.class);
                startActivity(i);
                break;
            case R.id.martin_button:
                Intent i2 = new Intent(this, Martin.class);
                startActivity(i2);
                break;
            case R.id.corsair_button:
                Intent i3 = new Intent(this, Corsair.class);
                startActivity(i3);
                break;
            case R.id.edge_button:
                Intent i4 = new Intent(this, Edge.class);
                startActivity(i4);
                break;
            case R.id.theater_button:
                Intent i5 = new Intent(this, SevenDTheater.class);
                startActivity(i5);
                break;
            case R.id.maxflight_button:
                Intent i6 = new Intent(this, MaxFlight.class);
                startActivity(i6);
                break;

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_load_simulators, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
